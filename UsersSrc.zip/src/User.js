const user = (props) =>{
    return(
    <div>
    <h3>Nazwa użytkownika: {props.nazwa}</h3>
    <h3>Rola: {props.rola}</h3>
    <p>Status: {props.children}</p>
    <button onClick = {props.buttonClick} className="FormButton">Pokaż użytkownika</button>
    </div>
    );
}
export default user;