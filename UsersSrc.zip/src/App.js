import React, { Component } from "react";
import User from "./User";
import Klient from "./Klient"
import "./App.css";


class App extends Component {
  active= "Aktywny";
  inactive= "Niekatywny";
state={
  username: "Kazimierz",
  role: "użytkownik",
  active: true
}  

setUserDataHandler = () =>{
  console.log("Przycisk wciśnięty.")
  const username = document.getElementById("username").value;
  const role = document.getElementById("role").value;
  const active = document.getElementById("active").checked;
   //Zapis nieprawidłowy
  //this.username=username;
  this.setState({
    username: username,
    role: role,
    active: active
  });
}  

onCopyHandler = () =>{
  console.log("skopiowano zawartość.")
}

onMouseEnterHandler = () =>{
  console.log("myszka wjechala na element");
}

onMouseLeaveHandler = () =>{
  console.log("myszka wyjechala z elementu");
}

render() {
return (
<div className="App">

  <h1 onCopy = {this.onCopyHandler}  onMouseEnter = {this.onMouseEnterHandler} onMouseLeave = {this.onMouseLeaveHandler}>Witam. Jestem aplikacja REACT.</h1>
<div className="Formularz">
<label className="FormLabel">Nazwa użytkownika:</label>
<input className = "FormElement" type="text" id="username"></input>
<label className="FormLabel">Rola:</label>
<input className = "FormElement" type="text" id="role"></input>
<label className="FormLabel">Aktywny:</label>
<input className = "FormElement" type="checkbox" id="active"></input>
  
<User nazwa={this.state.username} rola={this.state.role} buttonClick = {this.setUserDataHandler}>{this.state.active?this.active:this.inactive}</User>
</div>
<Klient/>
</div>
);
}
}
export default App;