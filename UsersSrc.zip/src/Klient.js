import React,{ useState } from "react";

const Klient = () => {

    const[klientState, setKlientState] = useState({
        nazwy: ['Jan', 'Piotr', 'Anna'],
        wybranaNazwa: 'Anna'
    });

    const zmienNazwe = () =>{
        do{
            var pulaNazw = klientState.nazwy;
            var number = Math.floor(Math.random() * 3);
        }while(klientState.wybranaNazwa === pulaNazw[number])
        setKlientState({...klientState,  wybranaNazwa: pulaNazw[number]});
    }

    return(
        <div>
            <h2>Klient: </h2>
            <h3>{klientState.wybranaNazwa}
            </h3>
            <button onClick={zmienNazwe}>Zmiana nazwy</button>
        </div>
    );
}

export default Klient;