import './App.css';
import React, {Component} from "react";
import Artykul from "./Artykul"
import { isDisabled } from '@testing-library/user-event/dist/utils';

class App extends Component{
  
  state = {
    artykuly: [
      {tytul: "Tytul1", tresc: "To jest tresc 1."},
      {tytul: "Tytul2", tresc: "To jest tresc 2."},
      {tytul: "Tytul3 ", tresc: "To jest tresc 3."},
      {tytul: "Tytul4 ", tresc: "To jest tresc 4."}
    ],
    pokazArtykuly:  false
  }
  
  PrzelaczArtykulyHandler = () =>{
    const pokaz = this.state.pokazArtykuly;
    this.setState({pokazArtykuly: !pokaz});
  }

  UsunArtykulHandler = (artykulIndex) =>{
    const artykuly = this.state.artykuly;
    
    artykuly.splice(artykulIndex,1);

    this.setState({artykuly: artykuly});
  }



  render(){

    let articles = null;
    
    if(this.state.pokazArtykuly){
      articles = this.state.artykuly.map((artykul,index) => (
        <Artykul tytul = {artykul.tytul} tresc = {artykul.tresc} UsunArtykul = {() =>this.UsunArtykulHandler(index)}/>
      ))
    }

    return(
      <div className='App'>

        <button onClick={this.PrzelaczArtykulyHandler}>Przełącz artykuły</button>
        {articles}

      </div>
    );
  }
}

export default App;
