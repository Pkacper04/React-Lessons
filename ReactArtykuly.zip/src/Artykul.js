const artykul = (props) =>{
    return(
        <>
            <h2>{props.tytul}</h2>
            <p>{props.tresc}</p>
            <button onClick={props.UsunArtykul}>Usuń artykuł</button>
            <br/>
            <br/>
        </>
    );
}

export default artykul;