import { useState } from "react";

const Car = (props) => {

    const[carState, setCarState] = useState(
         [   
            {
                marka: "Audi",
                model: "A6",
                rocznik: 2012
            },
            {
                marka: "Mercedes",
                model: "EQS",
                rocznik: 2020
            },
            {
                marka: "Opel",
                model: "Astra",
                rocznik: 2007
            }
        ]
    );

    let numberOfCars = 0

    for(let i=0;i<carState.length; i++)
    {
        if(Math.abs(carState[i].rocznik - props.rocznik) <= 5)
            numberOfCars++;
    }


    if(numberOfCars == 0)
    {
        return(
            <p>Nie znalezlismy dla ciebie samochodow</p>
        );
    }
    else{
        return(
            <div className="CarInfo">    
            <h1>Twoje samochody</h1>
            <p>------------------------</p>
            {carState.map((car)=> 
                {   
                    if(Math.abs(car.rocznik - props.rocznik) <= 5) {
                        return (
                            <div className="CarInfo">
                                <p>Marka: {car.marka}</p>
                                <p>Model: {car.model}</p>
                                <p>Rocznik: {car.rocznik}</p>
                                <p>------------------------</p>
                            </div>
                        )
                    }
                }
            )}
            </div>
        );
    }
}

export default Car;