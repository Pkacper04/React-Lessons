import './App.css';
import { Component } from 'react';
import Cars from "./Cars.js"

class App extends Component{

state = {
  rocznik:2000
}

setUserDataHandler = () =>{
    let rok = document.getElementById("rocznik").value;
    this.setState({
      rocznik: rok
    });
  }


render() {
  return (
    <div className="App">
        <label>Twoje imie</label><br></br>
        <input type="text"></input><br></br>
        <label>rocznik auta jakiego szukasz</label><br></br>
        <input type="number" id="rocznik"></input><br></br>
        <button onClick={this.setUserDataHandler}>Search</button>
        <Cars rocznik = {this.state.rocznik}></Cars>
    </div>
  );
}
}
export default App;
